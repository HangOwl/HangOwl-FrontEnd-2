import React from 'react';
import './CustomerHome.css';
import Navbar2 from '../components/Navbar/Navbar2';

const CustomerHome = () => {
    return (
     <div className="bg">
         <Navbar2 />
        Hello
        
    </div>
    );

};

export default CustomerHome;